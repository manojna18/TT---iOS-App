//
//  ContentView.swift
//  TenderThoughts
//
//  Created by Manogna Maddipatla on 12/15/23.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView{
            Welcome()
        }
       
    }
}

#Preview {
    ContentView()
}
