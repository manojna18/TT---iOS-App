//
//  TenderThoughtsApp.swift
//  TenderThoughts
//
//  Created by Manogna Maddipatla on 12/12/23.
//

import SwiftUI

@main
struct TenderThoughtsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
